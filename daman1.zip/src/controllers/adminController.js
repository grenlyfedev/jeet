import connection from "../config/connectDB";
import jwt from "jsonwebtoken";
import prisma from "../../prisma/prisma";
import md5 from "md5";
const multer = require('multer');
const fs = require('fs');
const path = require('path');
require("dotenv").config();

let timeNow = Date.now();


// Set up multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, 'uploads'));
  },
  filename: function (req, file, cb) {
    cb(null, `${Date.now()}_${file.originalname}`);
  }
});

// Initialize multer upload middleware with file size limit
const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 50 * 1024 * 1024 // 50 MB limit
  }
});

const dashboardData = async (req, res) => {
  try {
    let auth = req.cookies.auth;

    const [rows] = await connection.query(
      "SELECT * FROM users WHERE `token` = ?",
      [auth]
    );

    if (rows.length > 0) {
      // Fetch the required data from the database
      const [totalUsers] = await connection.query("SELECT COUNT(*) AS totalUsers FROM users");
      const [totalActiveUsers] = await connection.query("SELECT COUNT(*) AS totalActiveUsers FROM users WHERE status = 'active'");
      const [totalPendingFundRequests] = await connection.query("SELECT COUNT(*) AS totalPendingFundRequests FROM fund_requests WHERE status = 'pending'");
      const [todaysFundRequests] = await connection.query("SELECT COUNT(*) AS todaysFundRequests FROM fund_requests WHERE DATE(request_date) = CURDATE()");
      const [totalPendingWithdrawalRequests] = await connection.query("SELECT COUNT(*) AS totalPendingWithdrawalRequests FROM withdrawal_requests WHERE status = 'pending'");
      const [todaysWithdrawals] = await connection.query("SELECT COUNT(*) AS todaysWithdrawals FROM withdrawals WHERE DATE(date) = CURDATE()");
      const [totalPendingWithdrawalAmount] = await connection.query("SELECT COALESCE(SUM(amount), 0) AS totalPendingWithdrawalAmount FROM withdrawal_requests WHERE status = 'pending'");
      const [total5dBetAmount] = await connection.query("SELECT COALESCE(SUM(amount), 0) AS total5dBetAmount FROM bets WHERE game = '5d'");
      const [totalK3BetAmount] = await connection.query("SELECT COALESCE(SUM(amount), 0) AS totalK3BetAmount FROM bets WHERE game = 'k3'");
      const [totalWingoBetAmount] = await connection.query("SELECT COALESCE(SUM(amount), 0) AS totalWingoBetAmount FROM bets WHERE game = 'wingo'");
      const [totalAviatorBetAmount] = await connection.query("SELECT COALESCE(SUM(amount), 0) AS totalAviatorBetAmount FROM bets WHERE game = 'aviator'");

      const [CumulativeWithdrawals] = await connection.query("SELECT COALESCE(SUM(amount), 0) AS CumulativeWithdrawals FROM withdrawals");
      const [CumulativeDeposits] = await connection.query("SELECT COALESCE(SUM(money), 0) AS CumulativeDeposits FROM recharge");
      const [CumulativeWinningBonuses] = await connection.query("SELECT COALESCE(SUM(bonus), 0) AS CumulativeWinningBonuses FROM referral_bonus");
      const [CumulativeReferralBonuses] = await connection.query("SELECT COALESCE(SUM(bonus), 0) AS CumulativeReferralBonuses FROM referral_bonus");
      const [TotalGiftCards] = await connection.query("SELECT COALESCE(SUM(money), 0) AS TotalGiftCards FROM redenvelopes_used");
      const [TotalGiftCardsNotRedeemed] = await connection.query("SELECT COALESCE(SUM(money), 0) AS TotalGiftCardsNotRedeemed FROM redenvelopes");

      
      return res.status(200).json({
        message: "Success",
        status: true,
        totalUsers: totalUsers[0].totalUsers,
        totalActiveUsers: totalActiveUsers[0].totalActiveUsers,
        totalPendingFundRequests: totalPendingFundRequests[0].totalPendingFundRequests,
        todaysFundRequests: todaysFundRequests[0].todaysFundRequests,
        totalPendingWithdrawalRequests: totalPendingWithdrawalRequests[0].totalPendingWithdrawalRequests,
        todaysWithdrawals: todaysWithdrawals[0].todaysWithdrawals,
        totalPendingWithdrawalAmount: totalPendingWithdrawalAmount[0].totalPendingWithdrawalAmount,
        total5dBetAmount: total5dBetAmount[0].total5dBetAmount,
        totalK3BetAmount: totalK3BetAmount[0].totalK3BetAmount,
        totalWingoBetAmount: totalWingoBetAmount[0].totalWingoBetAmount,
        totalAviatorBetAmount: totalAviatorBetAmount[0].totalAviatorBetAmount,
        CumulativeReferralBonuses: CumulativeReferralBonuses[0].CumulativeReferralBonuses,
        CumulativeWinningBonuses: CumulativeWinningBonuses[0].CumulativeWinningBonuses,
        CumulativeDeposits: CumulativeDeposits[0].CumulativeDeposits,
        CumulativeWithdrawals: CumulativeWithdrawals[0].CumulativeWithdrawals,
        TotalGiftCards: TotalGiftCards[0].TotalGiftCards,
        TotalGiftCardsNotRedeemed: TotalGiftCardsNotRedeemed[0].TotalGiftCardsNotRedeemed,
        timeStamp: new Date().toISOString()
      });
    } else {
      return res.status(200).json({
        message: "Failed",
        status: false,
        timeStamp: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error("Error fetching dashboard data:", error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
      timeStamp: new Date().toISOString()
    });
  }
};





const listFundRequests = async (req, res) => {
  let { pageno, limit } = req.body;
  console.log(pageno, limit);

  if (!pageno || !limit) {
    return res.status(200).json({
      code: 0,
      msg: "Invalid page number or limit",
      data: {
        fundRequestsList: [],
      },
      status: false,
    });
  }

  if (pageno < 0 || limit < 0) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

     // Fetch fund requests from the database
     const [fundRequests] = await connection.query(
      `SELECT * FROM fund_requests ORDER BY id DESC LIMIT ${pageno}, ${limit} `

    );

    // Fetch total count of fund requests
    const [totalFundRequests] = await connection.query(
      `SELECT COUNT(*) AS count FROM fund_requests`
    );

    return res.status(200).json({
      message: "Success",
      status: true,
      datas: fundRequests,
      page_total: Math.ceil(totalFundRequests.length / limit),
    });

};


const searchFundRequests = async (req, res) => {
  const phone = req.body.phone;

  try {
    // Check if phone number is provided
    if (!phone) {
      return res.status(400).json({
        message: "Phone number is required",
        status: false,
      });
    }

    // Search for fund requests based on user's level
    let query;
    const auth = req.cookies.auth;
    const [user] = await connection.query(
      "SELECT `phone`, `code`, `invite`, `level` FROM users WHERE `token` = ?",
      [auth]
    );

    if (user.length === 0) {
      return res.status(401).json({
        message: "Unauthorized",
        status: false,
      });
    }

    const userInfo = user[0];

    if (userInfo.level === 1 || userInfo.level === 2) {
      query = `SELECT * FROM fund_requests WHERE phone = ? ORDER BY id DESC`;
    } else {
      return res.status(403).json({
        message: "Forbidden",
        status: false,
      });
    }

    // Execute the search query
    const [fundRequests] = await connection.query(query, [phone]);

    if (fundRequests.length === 0) {
      return res.status(404).json({
        message: "No fund requests found for the provided phone number",
        status: false,
      });
    }

    return res.status(200).json({
      message: "Success",
      data: fundRequests,
      status: true,
    });
  } catch (error) {
    console.error("Error searching for fund requests:", error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  }
};


const updateFundRequestStatus = async (req, res) => {
  const { requestId, action } = req.body;
  console.log('DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD');
  console.log(req.body);
  try {
    // Check if requestId and action are provided
    if (!requestId || !action) {
      return res.status(400).json({
        message: "Request ID and action are required",
        status: false,
      });
    }

    // Check if the action is valid
    const validActions = ["approved", "rejected"];
    if (!validActions.includes(action.toLowerCase())) {
      return res.status(400).json({
        message: "Invalid action value",
        status: false,
      });
    }

    // Update the status of the fund request
    const [result] = await connection.query(
      "UPDATE fund_requests SET status = ?, state = ? WHERE id = ?",
      [action, action, requestId]
    );
    console.log(result);

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Fund request not found",
        status: false,
      });
    }

    return res.status(200).json({
      message: "Fund request status updated successfully",
      status: true,
    });
  } catch (error) {
    console.error("Error updating fund request status:", error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  }
};



const updateReferralCodeStatus = async (req, res) => {
  console.log('(((((((((((((((((((((((((((((((((((((((');
  console.log(req.body);
  const { userId, status } = req.body;
  try {
    // Check if userId and status are provided
    if (!userId || !status) {
      return res.status(400).json({
        message: "User ID and status are required",
        status: false,
      });
    }

    console.log('HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH');
    // Check if the status is valid
    const validStatus = ["1", "0"];
    if (!validStatus.includes(status.toLowerCase())) {
      return res.status(400).json({
        message: "Invalid status value",
        status: false,
      });
    }
    console.log('DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD');
    // Your raw SQL query to update the referral code status
    const query = `UPDATE users SET referralCodeStatus = ? WHERE id = ?`;

    // Execute the query using the connection
    await connection.query(query, [status, userId]);

    // Update the status of the user's referral code
    // Assuming you're using a database library like Knex.js for SQL queries
    // Replace this with your actual database update logic
    // await knex('users').where('id', userId).update({ referralCodeStatus: status });

    return res.status(200).json({
      message: "Referral code status updated successfully",
      status: true,
    });
  } catch (error) {
    console.error("Error updating referral code status:", error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  }
};




const updateWithdrawRequestStatus = async (req, res) => {
  const { requestId, status } = req.body;
  try {
    // Check if requestId and status are provided
    if (!requestId || !status) {
      return res.status(400).json({
        message: "Request ID and status are required",
        status: false,
      });
    }

    // Check if the status is valid
    const validStatusValues = ["approved", "pending", "rejected"];
    if (!validStatusValues.includes(status.toLowerCase())) {
      return res.status(400).json({
        message: "Invalid status value",
        status: false,
      });
    }

    // Update the status of the withdrawal request
    const [result] = await connection.query(
      "UPDATE withdrawal_requests SET status = ? WHERE id = ?",
      [status, requestId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Withdrawal request not found",
        status: false,
      });
    }

    return res.status(200).json({
      message: "Withdrawal request status updated successfully",
      status: true,
    });
  } catch (error) {
    console.error("Error updating withdrawal request status:", error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  }
};

const updateRemark = async (req, res) => {
  const { requestId, remark, tableName } = req.body;
  console.log(req.body);
  try {
    // Check if requestId, remark, and tableName are provided
    if (!requestId || !remark || !tableName) {
      return res.status(400).json({
        message: "Request ID, remark, and table name are required",
        status: false,
      });
    }

    console.log('TTTTTTTTTTTTTTTTTTTTT');

    // Update the remark in the specified table
    const [result] = await connection.query(
      `UPDATE ${tableName} SET remark = ? WHERE id = ?`,
      [remark, requestId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Record not found",
        status: false,
      });
    }
    console.log('RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR');

    return res.status(200).json({
      message: "Remark updated successfully",
      status: true,
    });
  } catch (error) {
    console.error("Error updating remark:", error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  }
};



const ledgerView = async (req, res) => {
  try {
    let userId = req.params.id;

    const userQuery = `
      SELECT * FROM users WHERE phone = ?;
    `;

    const combinedQuery = `
      SELECT 'withdrawal' AS category, id, user_id, amount AS money, NULL AS transaction_id, NULL AS phone, NULL AS type, NULL AS status, date, NULL AS url, NULL AS utr
      FROM withdrawals
      WHERE user_id = (
          SELECT id FROM users WHERE phone = ?
      )
      UNION ALL
      SELECT 'recharge' AS category, id, user_id, money AS amount, transaction_id, phone, type, status, date, url, utr
      FROM recharge
      WHERE user_id = (
          SELECT id FROM users WHERE phone = ?
      )
      ORDER BY date;
    `;

    // Fetch user data
    const [userData] = await connection.query(userQuery, [userId]);
    const user = userData[0]; // Assuming only one user with the given ID exists

    // Fetch combined withdrawals and recharges
    const [combinedData] = await connection.query(combinedQuery, [userId, userId]);

    // Render the data to the ledger view
    return res.render("manage/ledgerView.ejs", {
      user,
      transactions: combinedData
    });
  } catch (error) {
    console.error('Error fetching ledger data:', error);
    return res.status(500).send('Internal Server Error');
  }
};

const referralCodesView = async (req, res) => {
  try {
    let userId = req.params.id;

    const userQuery = `
      SELECT * FROM users WHERE phone = ?;
    `;

    const referralQuery = `
      SELECT 
        u_referrer.id_user AS referrer_id_user,
        u_referrer.name_user AS referrer_name_user,
        u_referrer.phone AS referrer_phone,
        u_referrer.level AS referrer_level,
        u_referrer.MyRefereeCode AS referrer_MyRefereeCode,
        u_referrer.referralCode AS referrer_referralCode,
        u_referrer.totalReferrals AS referrer_totalReferrals,
        u_referrer.totalDeposits AS referrer_totalDeposits,
        u_referrer.referralBonus AS referrer_referralBonus,
        u_referrer.referralCodeStatus AS referrer_referralCodeStatus,
        IFNULL(0.1 * u_referrer.totalDeposits, 0) AS referrer_totalBonus,
        
        u_referred.id_user AS referred_id_user,
        u_referred.name_user AS referred_name_user,
        u_referred.phone AS referred_phone,
        u_referred.level AS referred_level,
        u_referred.MyRefereeCode AS referred_MyRefereeCode,
        u_referred.referralCode AS referred_referralCode,
        u_referred.totalReferrals AS referred_totalReferrals,
        u_referred.totalDeposits AS referred_totalDeposits,
        u_referred.referralBonus AS referred_referralBonus,
        u_referred.referralCodeStatus AS referred_referralCodeStatus,
        IFNULL(0.1 * u_referred.totalDeposits, 0) AS referred_totalBonus,
        
        rb.bonus,
        rb.created_at
      FROM referral_bonus rb
      JOIN users u_referrer ON rb.user_id = u_referrer.id
      JOIN users u_referred ON rb.referred_user_id = u_referred.id
      WHERE u_referrer.id_user = ?;
    `;

    // Fetch user data
    const [userData] = await connection.query(userQuery, [userId]);
    const user = userData[0]; // Assuming only one user with the given ID exists

    const [referralData] = await connection.query(referralQuery, [user.id_user]);

    // Render the data to the referralCodesView
    return res.render("manage/referralCodesView.ejs", {
      user,
      referrals: referralData
    });
  } catch (error) {
    console.error('Error fetching referral data:', error);
    return res.status(500).send('Internal Server Error');
  }
};





const saveUpiSettings = async (req, res) => {
  try {
      const { upiId } = req.body;
      let qrCodeUrl = req.body.qrCodeUrl; // This will be updated if a file is uploaded

      // Handle file upload
      if (req.files && req.files.upiQr) {
          const file = req.files.upiQr;
          const uploadPath = '/path/to/upload/directory/' + file.name; // Adjust the path as needed
          await file.mv(uploadPath);
          qrCodeUrl = uploadPath;
      }

      // Check if the first entry exists
      const [existingSettings] = await connection.query("SELECT * FROM PaymentSettings LIMIT 1");

      // If no existing entry, create a new one
      if (!existingSettings || existingSettings.length === 0) {
          await connection.query(
              "INSERT INTO PaymentSettings (upiId, qrCodeUrl, wowPayAccount, upiToken) VALUES (?, ?, '', '')",
              [upiId, qrCodeUrl]
          );
      } else {
          // If existing entry, update the UPI settings
          await connection.query(
              "UPDATE PaymentSettings SET upiId = ?, qrCodeUrl = ? WHERE id = ?",
              [upiId, qrCodeUrl, existingSettings.id]
          );
      }

      console.log('UPI settings saved successfully.');
      res.redirect('/admin/manager/paymentSettings');
  } catch (error) {
      console.error('Error saving UPI settings:', error);
      return res.status(500).send(error.toString());
  }
};


const saveWowpaySettings = async (req, res) => {
  try {
      const { wowPayAccount } = req.body;

      // Check if the first entry exists
      const [existingSettings] = await connection.query("SELECT * FROM PaymentSettings LIMIT 1");

      // If no existing entry, create a new one
      if (!existingSettings || existingSettings.length === 0) {
          await connection.query(
              "INSERT INTO PaymentSettings (upiId, qrCodeUrl, wowPayAccount, upiToken) VALUES ('', '', ?, '')",
              [wowPayAccount]
          );
      } else {
          // If existing entry, update the WOWPay settings
          await connection.query(
              "UPDATE PaymentSettings SET wowPayAccount = ? WHERE id = ?",
              [wowPayAccount, existingSettings.id]
          );
      }

      console.log('WOWPay settings saved successfully.');
      res.redirect('/admin/manager/paymentSettings');
  } catch (error) {
      console.error('Error saving WOWPay settings:', error);
      return res.status(500).send(error.toString());
  }
};



const saveUpiTokenSettings = async (req, res) => {
  try {
      const { upiToken } = req.body;

      // Check if the first entry exists
      const [existingSettings] = await connection.query("SELECT * FROM PaymentSettings LIMIT 1");

      // If no existing entry, create a new one
      if (!existingSettings || existingSettings.length === 0) {
          await connection.query(
              "INSERT INTO PaymentSettings (upiId, qrCodeUrl, wowPayAccount, upiToken) VALUES ('', '', '', ?)",
              [upiToken]
          );
      } else {
          // If existing entry, update the UPI Token settings
          await connection.query(
              "UPDATE PaymentSettings SET upiToken = ? WHERE id = ?",
              [upiToken, existingSettings.id]
          );
      }

      console.log('UPI Token settings saved successfully.');
      res.redirect('/admin/manager/paymentSettings');
  } catch (error) {
      console.error('Error saving UPI Token settings:', error);
      return res.status(500).send(error.toString());
  }
};


const SavePaymentSettings = async (req, res) => {
  try {
      const { upiId, wowPayAccount, upiToken, usdtId } = req.body;
      let { qrCodeUrl, usdtQrCodeUrl } = req.body; // These will be updated if files are uploaded

      // Handle UPI QR code upload
      if (req.files && req.files.upiQr) {
          const upiQrFile = req.files.upiQr;
          const upiUploadPath = '/path/to/upload/directory/' + upiQrFile.name; // Adjust the path as needed
          await upiQrFile.mv(upiUploadPath);
          qrCodeUrl = upiUploadPath;
      }

      // Handle USDT QR code upload
      if (req.files && req.files.usdtQr) {
          const usdtQrFile = req.files.usdtQr;
          const usdtUploadPath = '/path/to/upload/directory/' + usdtQrFile.name; // Adjust the path as needed
          await usdtQrFile.mv(usdtUploadPath);
          usdtQrCodeUrl = usdtUploadPath;
      }

      // Check if the first entry exists
      const [existingSettings] = await connection.query("SELECT * FROM PaymentSettings LIMIT 1");

      // If no existing entry, create a new one
      if (!existingSettings || existingSettings.length === 0) {
          await connection.query(
              "INSERT INTO PaymentSettings (upiId, qrCodeUrl, wowPayAccount, upiToken, usdtId, usdtQrCodeUrl) VALUES (?, ?, ?, ?, ?, ?)",
              [upiId, qrCodeUrl, wowPayAccount, upiToken, usdtId, usdtQrCodeUrl]
          );
      } else {
          // If existing entry, update the settings
          await connection.query(
              "UPDATE PaymentSettings SET upiId = ?, qrCodeUrl = ?, wowPayAccount = ?, upiToken = ?, usdtId = ?, usdtQrCodeUrl = ? WHERE id = ?",
              [upiId, qrCodeUrl, wowPayAccount, upiToken, usdtId, usdtQrCodeUrl, existingSettings.id]
          );
      }

      console.log('Payment settings saved successfully.');
      res.redirect('/admin/manager/paymentSettings');
  } catch (error) {
      console.error('Error saving payment settings:', error);
      return res.status(500).send(error.toString());
  }
};





const dashboard = async (req, res) => {
  return res.render("manage/dashboard.ejs");
};
const fundRequests = async (req, res) => {
  return res.render("manage/fundRequests.ejs");
};
const paymentHistory = async (req, res) => {
  return res.render("manage/paymentHistory.ejs");
};
const ledgerHistory = async (req, res) => {
  return res.render("manage/ledgerHistory.ejs");
};

const adminPage = async (req, res) => {
  return res.render("manage/index.ejs");
};

const adminPage3 = async (req, res) => {
  return res.render("manage/a-index-bet/index3.ejs");
};

const adminPage5 = async (req, res) => {
  return res.render("manage/a-index-bet/index5.ejs");
};

const adminPage10 = async (req, res) => {
  return res.render("manage/a-index-bet/index10.ejs");
};

const adminPage5d = async (req, res) => {
  return res.render("manage/5d.ejs");
};

const adminPageK3 = async (req, res) => {
  return res.render("manage/k3.ejs");
};

const ctvProfilePage = async (req, res) => {
  var phone = req.params.phone;
  return res.render("manage/profileCTV.ejs", { phone });
};

const giftPage = async (req, res) => {
  return res.render("manage/giftPage.ejs");
};

const referralCodes = async (req, res) => {
  return res.render("manage/referralCodes.ejs");
};

const membersPage = async (req, res) => {
  return res.render("manage/members.ejs");
};

const ctvPage = async (req, res) => {
  return res.render("manage/ctv.ejs");
};

const infoMember = async (req, res) => {
  let phone = req.params.id;
  const userQuery = `
    SELECT * FROM users WHERE phone = ?;
  `;
  // Fetch user data
  const [userData] = await connection.query(userQuery, [phone]);
  const user = userData[0]; // Assuming only one user with the given ID exists
  return res.render("manage/profileMember.ejs", { phone, user });
};

const statistical = async (req, res) => {
  return res.render("manage/statistical.ejs");
};

const rechargePage = async (req, res) => {
  return res.render("manage/recharge.ejs");
};
const k3history = async (req, res) => {
  return res.render("manage/k3history.ejs");
};
const d5history = async (req, res) => {
  return res.render("manage/5dhistory.ejs");
};
const wingoHistory = async (req, res) => {
  return res.render("manage/wingohistory.ejs");
};
const rechargeRecord = async (req, res) => {
  return res.render("manage/rechargeRecord.ejs");
};

const withdraw = async (req, res) => {
  try {
    // Query transactions with user information using a JOIN operation
    const [transactions] = await connection.query(`
      SELECT w.*, u.phone, u.name_user
      FROM withdrawal_requests w
      JOIN users u ON w.user_id = u.id
    `);

    // Render the withdraw.ejs template with transactions data
    return res.render("manage/withdraw.ejs", { transactions });
  } catch (error) {
    console.error("Error fetching transactions:", error);
    // Handle error response
    return res.status(500).send("Internal Server Error");
  }
};

const getUserInfo = async (req, res, next) => {
  try {
    const token = getCokkie;
    return res.status(200).json({
      status: true,
      user: req.user,
      bank: req.bank,
      key: req.key,
    });
  } catch (err) {
    return res.status(404).json({
      status: false,
      message: err.message,
    });
  }
};
const withdrawRecord = async (req, res) => {
  return res.render("manage/withdrawRecord.ejs");
};
const settings = async (req, res) => {
  return res.render("manage/settings.ejs");
};

const paymentSettings = async (req, res) => {
  console.log('OOOOOOOOOOOOOOOOOOOOOOOOO');
  console.log(req.body);
  try {
      if (req.method === "POST") {
        console.log(req.body);
          // Extract form data from the request body
          const {
              upiId, usdtId, wowPayAccount, upiToken,
              bankName, accountHolderName, accountNumber, ifsc
          } = req.body;

          console.log(req.body);

          // Extract file paths if files were uploaded
          const qrCodeUrl = req.files.qrCodeUrl ? req.files.qrCodeUrl[0].path : '';
          const usdtQrCodeUrl = req.files.usdtQrCodeUrl ? req.files.usdtQrCodeUrl[0].path : '';

          // Update the first row in the PaymentSettings table
          await connection.query(
              `UPDATE PaymentSettings SET
                  upiId = ?, qrCodeUrl = ?, usdtId = ?, wowPayAccount = ?,
                  upiToken = ?, usdtQrCodeUrl = ?, bankName = ?, accountHolderName = ?,
                  accountNumber = ?, ifsc = ?
              WHERE id = 1`,
              [upiId, qrCodeUrl, usdtId, wowPayAccount, upiToken, usdtQrCodeUrl, bankName, accountHolderName, accountNumber, ifsc]
          );

          return res.redirect('/admin/manager/paymentSettings');
      } else {
          // Execute the SQL query to retrieve payment settings
          const [rows] = await connection.query('SELECT * FROM PaymentSettings LIMIT 1');

          // Extract the first row if it exists
          const settings = rows.length > 0 ? rows[0] : null;
          return res.render("manage/paymentSettings.ejs", { settings });
      }
  } catch (error) {
      console.error('Error retrieving or updating payment settings:', error);
      return res.status(500).send(error.toString());
  }
};

const saveScreenshotWithMulter = async (base64Data) => {
  try {
      // Extract the mime type and base64 encoded image data from the string
      const matches = base64Data.match(/^data:(.+);base64,(.+)/);
      if (!matches || matches.length !== 3) {
          throw new Error('Invalid base64 image data');
      }

      // Extract the mime type and image data
      const mimeType = matches[1];
      const imageData = matches[2];

      // Convert base64 encoded image data to binary buffer
      const imageBuffer = Buffer.from(imageData, 'base64');

      // Generate a unique filename for the uploaded file (or use a specific name pattern)
      const fileName = `screenshot_${Date.now()}.${mimeType.split('/')[1]}`;

      // Specify the destination folder where the file will be saved
      // const uploadPath = './uploads/' + fileName;
      // Specify the destination folder where the file will be saved
      const uploadPath = '/home/uploads/' + fileName;

      // Write the binary data to the file
      await fs.promises.writeFile(uploadPath, imageBuffer);

      // Return the filename or full path if needed
      const fileUrl = 'http://fxvoyager.com/uploads/' + fileName;
      return fileUrl;
  } catch (error) {
      console.error('Error saving screenshot:', error);
      throw error;
  }
};



const ensureUploadsFolderExists = () => {
  const uploadFolderPath = path.join(__dirname, 'uploads');
  if (!fs.existsSync(uploadFolderPath)) {
      console.log(`'uploads' folder does not exist. Creating it at: ${uploadFolderPath}`);
      fs.mkdirSync(uploadFolderPath);
  }
};

const updatePaymentSettings = async (req, res) => {
  try {
      ensureUploadsFolderExists();
      
      upload.single('file')(req, res, async (err) => {
          if (err instanceof multer.MulterError) {
              // A Multer error occurred when uploading
              return res.status(500).json({ message: 'File upload error', status: false });
          } else if (err) {
              // An unknown error occurred
              return res.status(500).json({ message: 'Unknown error', status: false });
          }
            // Get auth and token from request headers
            const auth = req.body.auth;
            const token = req.body.token;



          const usdtQrCodeImage = req.body.usdtQrCodeImage;

          // Save the screenshot with Multer
          const usdtQrCodeImageUrl = await saveScreenshotWithMulter(usdtQrCodeImage);


          const upiQrCodeImage = req.body.upiQrCodeImage;

          const upiQrCodeImageUrl = await saveScreenshotWithMulter(upiQrCodeImage);
          // console.log(req.body);



          // Extract form data from the request body
          const { upiId, usdtId, wowPayAccount, upiToken, bankName, accountHolderName, accountNumber, ifsc, minWithdraw, minBetAmount, minDeposit, referralBonus   } = req.body;
          console.log( upiId, usdtId, wowPayAccount, upiToken, bankName, accountHolderName, accountNumber, ifsc, minWithdraw, minBetAmount, minDeposit, referralBonus);

   
          // Update the PaymentSettings table based on image availability
          if (upiQrCodeImageUrl && usdtQrCodeImageUrl) {
            await connection.execute(
                `UPDATE PaymentSettings SET
                upiId = ?, qrCodeUrl = ?, usdtId = ?, wowPayAccount = ?, upiToken = ?, usdtQrCodeUrl = ?, bankName = ?,
                accountHolderName = ?, accountNumber = ?, ifsc = ?, maxWithdraw = ?, minBetAmount = ?, minDeposit = ?,  referralBonus = ?
                WHERE id = 1`,
                [upiId, upiQrCodeImageUrl, usdtId, wowPayAccount, upiToken, usdtQrCodeImageUrl, bankName, accountHolderName, accountNumber, ifsc, minWithdraw, minBetAmount, minDeposit, referralBonus ]
            );
        } else if (upiQrCodeImageUrl && !usdtQrCodeImageUrl) {
            await connection.execute(
                `UPDATE PaymentSettings SET
                upiId = ?, qrCodeUrl = ?, usdtId = ?, wowPayAccount = ?, upiToken = ?, bankName = ?,
                accountHolderName = ?, accountNumber = ?, ifsc = ?, maxWithdraw = ?, minBetAmount = ?, minDeposit = ?,  referralBonus = ?
                WHERE id = 1`,
                [upiId, upiQrCodeImageUrl, usdtId, wowPayAccount, upiToken, bankName, accountHolderName, accountNumber, ifsc, minWithdraw, minBetAmount, minDeposit, referralBonus ]
            );
        } else if (!upiQrCodeImageUrl && usdtQrCodeImageUrl) {
            await connection.execute(
                `UPDATE PaymentSettings SET
                upiId = ?, usdtId = ?, wowPayAccount = ?, upiToken = ?, usdtQrCodeUrl = ?, bankName = ?,
                accountHolderName = ?, accountNumber = ?, ifsc = ?, maxWithdraw = ?, minBetAmount = ?, minDeposit = ?,  referralBonus = ?
                WHERE id = 1`,
                [upiId, usdtId, wowPayAccount, upiToken, usdtQrCodeImageUrl, bankName, accountHolderName, accountNumber, ifsc, minWithdraw, minBetAmount, minDeposit, referralBonus ]
            );
        }

          // Extract form data from the request body
          // const { upiId, usdtId, wowPayAccount, upiToken, bankName, accountHolderName, accountNumber, ifsc, minWithdraw, minBetAmount, minDeposit, referralBonus } = req.body;
          // console.log(upiId, usdtId, wowPayAccount, upiToken, bankName, accountHolderName, accountNumber, ifsc, minWithdraw, minBetAmount, minDeposit, referralBonus);

          // // Update the PaymentSettings table based on image availability
          // if (upiQrCodeImageUrl && usdtQrCodeImageUrl) {
          //     await connection.execute(
          //         `UPDATE PaymentSettings SET
          //         upiId = ?, qrCodeUrl = ?, usdtId = ?, wowPayAccount = ?, upiToken = ?, usdtQrCodeUrl = ?, bankName = ?,
          //         accountHolderName = ?, accountNumber = ?, ifsc = ?, maxWithdraw = ?, minBetAmount = ?, minDeposit = ?, referralBonus = ?
          //         WHERE id = 1`,
          //         [upiId, upiQrCodeImageUrl, usdtId, wowPayAccount, upiToken, usdtQrCodeImageUrl, bankName, accountHolderName, accountNumber, ifsc, minWithdraw, minBetAmount, minDeposit, referralBonus]
          //     );
          // } else if (upiQrCodeImageUrl && !usdtQrCodeImageUrl) {
          //     await connection.execute(
          //         `UPDATE PaymentSettings SET
          //         upiId = ?, qrCodeUrl = ?, usdtId = ?, wowPayAccount = ?, upiToken = ?, bankName = ?,
          //         accountHolderName = ?, accountNumber = ?, ifsc = ?, maxWithdraw = ?, minBetAmount = ?, minDeposit = ?, referralBonus = ?
          //         WHERE id = 1`,
          //         [upiId, upiQrCodeImageUrl, usdtId, wowPayAccount, upiToken, bankName, accountHolderName, accountNumber, ifsc, minWithdraw, minBetAmount, minDeposit, referralBonus]
          //     );
          // } else if (!upiQrCodeImageUrl && usdtQrCodeImageUrl) {
          //     await connection.execute(
          //         `UPDATE PaymentSettings SET
          //         upiId = ?, usdtId = ?, wowPayAccount = ?, upiToken = ?, usdtQrCodeUrl = ?, bankName = ?,
          //         accountHolderName = ?, accountNumber = ?, ifsc = ?, maxWithdraw = ?, minBetAmount = ?, minDeposit = ?, referralBonus = ?
          //         WHERE id = 1`,
          //         [upiId, usdtId, wowPayAccount, upiToken, usdtQrCodeImageUrl, bankName, accountHolderName, accountNumber, ifsc, minWithdraw, minBetAmount, minDeposit, referralBonus]
          //     );
          // }



          // Return response
          return res.status(200).json({
              message: "Image uploaded and request created successfully",
              status: true,
              timeStamp: new Date().toISOString(),
          });
      });
  } catch(error) {
      console.log(error);
      return res.status(500).json({
          message: "Internal server error",
          status: false,
          timeStamp: new Date().toISOString(),
      });
  }
};


// xác nhận admin
const middlewareAdminController = async (req, res, next) => {
  // xác nhận token
  const auth = req.cookies.auth;
  if (!auth) {
    return res.redirect("/login");
  }
  const [rows] = await connection.execute(
    "SELECT `token`,`level`, `status` FROM `users` WHERE `token` = ? AND veri = 1",
    [auth]
  );
  if (!rows) {
    return res.redirect("/login");
  }
  try {
    if (auth == rows[0].token && rows[0].status == 1) {
      if (rows[0].level == 1) {
        next();
      } else {
        return res.redirect("/home");
      }
    } else {
      return res.redirect("/login");
    }
  } catch (error) {
    return res.redirect("/login");
  }
};
const getAllUserData = async (req, res) => {
  try {
    const { page, limit } = req.query;
    const skip = (page - 1) * limit;
    const alldata = await prisma.users.findMany({
      where: {
        token: {
          not: "0",
        },
      },
    });
    const data = await prisma.users.findMany({
      skip: Number(skip),
      take: Number(limit),
      orderBy: {
        id: "desc",
      },
      where: {
        token: {
          not: "0",
        },
      },
    });

    return res.status(200).json({
      status: true,
      message: "userData Successfully fetched!...",
      data,
      length: alldata.length,
    });
  } catch (err) {
    return res.status(401).json({
      status: false,
      message: err.message,
    });
  }
};
const getAllRechargeDetails = async (req, res) => {
  try {
    const { page, limit } = req.query;
    const skip = (page - 1) * limit;
    const alldata = await prisma.aviatorrecharge.findMany();
    const data = await prisma.aviatorrecharge.findMany({
      skip: Number(skip),
      take: Number(limit),
      orderBy: {
        id: "desc",
      },
    });
    return res.status(200).json({
      status: true,
      message: "RechargeData Successfully fetched!...",
      data,
      length: alldata.length,
    });
  } catch (err) {
    return res.status(401).json({
      status: false,
      message: err.message,
    });
  }
};
const totalJoin = async (req, res) => {
  let auth = req.cookies.auth;
  let typeid = req.body.typeid;
  if (!typeid) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  let game = "";
  if (typeid == "1") game = "wingo";
  if (typeid == "2") game = "wingo3";
  if (typeid == "3") game = "wingo5";
  if (typeid == "4") game = "wingo10";

  const [rows] = await connection.query(
    "SELECT * FROM users WHERE `token` = ? ",
    [auth]
  );

  if (rows.length > 0) {
    const [wingoall] = await connection.query(
      `SELECT * FROM minutes_1 WHERE game = "${game}" AND status = 0 AND level = 0 ORDER BY id ASC `,
      [auth]
    );
    const [winGo1] = await connection.execute(
      `SELECT * FROM wingo WHERE status = 0 AND game = '${game}' ORDER BY id DESC LIMIT 1 `,
      []
    );
    const [winGo10] = await connection.execute(
      `SELECT * FROM wingo WHERE status != 0 AND game = '${game}' ORDER BY id DESC LIMIT 10 `,
      []
    );
    const [setting] = await connection.execute(`SELECT * FROM admin `, []);

    return res.status(200).json({
      message: "Success",
      status: true,
      datas: wingoall,
      lotterys: winGo1,
      list_orders: winGo10,
      setting: setting,
      timeStamp: timeNow,
    });
  } else {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
};

const listMember = async (req, res) => {
  let { pageno, limit } = req.body;

  if (!pageno || !limit) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

  if (pageno < 0 || limit < 0) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }
  const [users] = await connection.query(
    `SELECT * FROM users WHERE veri = 1 AND level != 2 ORDER BY id DESC LIMIT ${pageno}, ${limit} `
  );
  const [total_users] = await connection.query(
    `SELECT * FROM users WHERE veri = 1 AND level != 2`
  );
  return res.status(200).json({
    message: "Success",
    status: true,
    datas: users,
    page_total: Math.ceil(total_users.length / limit),
  });
};

const listCTV = async (req, res) => {
  let { pageno, pageto } = req.body;

  if (!pageno || !pageto) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

  if (pageno < 0 || pageto < 0) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }
  const [wingo] = await connection.query(
    `SELECT * FROM users WHERE veri = 1 AND level = 2 ORDER BY id DESC LIMIT ${pageno}, ${pageto} `
  );
  return res.status(200).json({
    message: "Success",
    status: true,
    datas: wingo,
  });
};

function formateT2(params) {
  let result = params < 10 ? "0" + params : params;
  return result;
}

function timerJoin2(params = "") {
  let date = "";
  if (params) {
    date = new Date(Number(params));
  } else {
    date = Date.now();
    date = new Date(Number(date));
  }
  let years = formateT2(date.getFullYear());
  let months = formateT2(date.getMonth() + 1);
  let days = formateT2(date.getDate());

  return years + "-" + months + "-" + days;
}

const statistical2 = async (req, res) => {
  const [wingo] = await connection.query(
    `SELECT SUM(money) as total FROM minutes_1 WHERE status = 1 `
  );
  const [wingo2] = await connection.query(
    `SELECT SUM(money) as total FROM minutes_1 WHERE status = 2 `
  );
  const [users] = await connection.query(
    `SELECT COUNT(id) as total FROM users WHERE status = 1 `
  );
  const [users2] = await connection.query(
    `SELECT COUNT(id) as total FROM users WHERE status = 0 `
  );
  const [recharge] = await connection.query(
    `SELECT SUM(money) as total FROM recharge WHERE status = 1 `
  );
  const [withdraw] = await connection.query(
    `SELECT SUM(money) as total FROM withdraw WHERE status = 1 `
  );

  const [recharge_today] = await connection.query(
    `SELECT SUM(money) as total FROM recharge WHERE status = 1 AND today = ?`,
    [timerJoin2()]
  );
  const [withdraw_today] = await connection.query(
    `SELECT SUM(money) as total FROM withdraw WHERE status = 1 AND today = ?`,
    [timerJoin2()]
  );

  let win = wingo[0].total;
  let loss = wingo2[0].total;
  let usersOnline = users[0].total;
  let usersOffline = users2[0].total;
  let recharges = recharge[0].total;
  let withdraws = withdraw[0].total;
  return res.status(200).json({
    message: "Success",
    status: true,
    win: win,
    loss: loss,
    usersOnline: usersOnline,
    usersOffline: usersOffline,
    recharges: recharges,
    withdraws: withdraws,
    rechargeToday: recharge_today[0].total,
    withdrawToday: withdraw_today[0].total,
  });
};

const changeAdmin = async (req, res) => {
  let auth = req.cookies.auth;
  let value = req.body.value;
  let type = req.body.type;
  let typeid = req.body.typeid;

  if (!value || !type || !typeid)
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  let game = "";
  let bs = "";
  if (typeid == "1") {
    game = "wingo1";
    bs = "bs1";
  }
  if (typeid == "2") {
    game = "wingo3";
    bs = "bs3";
  }
  if (typeid == "3") {
    game = "wingo5";
    bs = "bs5";
  }
  if (typeid == "4") {
    game = "wingo10";
    bs = "bs10";
  }
  switch (type) {
    case "change-wingo1":
      await connection.query(`UPDATE admin SET ${game} = ? `, [value]);
      return res.status(200).json({
        message: "Editing results successfully",
        status: true,
        timeStamp: timeNow,
      });
      break;
    case "change-win_rate":
      await connection.query(`UPDATE admin SET ${bs} = ? `, [value]);
      return res.status(200).json({
        message: "Editing win rate successfully",
        status: true,
        timeStamp: timeNow,
      });
      break;

    default:
      return res.status(200).json({
        message: "Failed",
        status: false,
        timeStamp: timeNow,
      });
      break;
  }
};

function formateT(params) {
  let result = params < 10 ? "0" + params : params;
  return result;
}

function timerJoin(params = "") {
  let date = "";
  if (params) {
    date = new Date(Number(params));
  } else {
    date = Date.now();
    date = new Date(Number(date));
  }
  let years = formateT(date.getFullYear());
  let months = formateT(date.getMonth() + 1);
  let days = formateT(date.getDate());
  let weeks = formateT(date.getDay());

  let hours = formateT(date.getHours());
  let minutes = formateT(date.getMinutes());
  let seconds = formateT(date.getSeconds());
  // return years + '-' + months + '-' + days + ' ' + hours + '-' + minutes + '-' + seconds;
  return years + " - " + months + " - " + days;
}

const userInfo = async (req, res) => {
  let auth = req.cookies.auth;
  let phone = req.body.phone;
  if (!phone) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }

  const [user] = await connection.query(
    "SELECT * FROM users WHERE phone = ? ",
    [phone]
  );

  if (user.length == 0) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  let userInfo = user[0];
  // cấp dưới trực tiếp all
  const [f1s] = await connection.query(
    "SELECT `phone`, `code`,`invite`, `time` FROM users WHERE `invite` = ? ",
    [userInfo.code]
  );

  // cấp dưới trực tiếp hôm nay
  let f1_today = 0;
  for (let i = 0; i < f1s.length; i++) {
    const f1_time = f1s[i].time; // Mã giới thiệu f1
    let check = timerJoin(f1_time) == timerJoin() ? true : false;
    if (check) {
      f1_today += 1;
    }
  }

  // tất cả cấp dưới hôm nay
  let f_all_today = 0;
  for (let i = 0; i < f1s.length; i++) {
    const f1_code = f1s[i].code; // Mã giới thiệu f1
    const f1_time = f1s[i].time; // time f1
    let check_f1 = timerJoin(f1_time) == timerJoin() ? true : false;
    if (check_f1) f_all_today += 1;
    // tổng f1 mời đc hôm nay
    const [f2s] = await connection.query(
      "SELECT `phone`, `code`,`invite`, `time` FROM users WHERE `invite` = ? ",
      [f1_code]
    );
    for (let i = 0; i < f2s.length; i++) {
      const f2_code = f2s[i].code; // Mã giới thiệu f2
      const f2_time = f2s[i].time; // time f2
      let check_f2 = timerJoin(f2_time) == timerJoin() ? true : false;
      if (check_f2) f_all_today += 1;
      // tổng f2 mời đc hôm nay
      const [f3s] = await connection.query(
        "SELECT `phone`, `code`,`invite`, `time` FROM users WHERE `invite` = ? ",
        [f2_code]
      );
      for (let i = 0; i < f3s.length; i++) {
        const f3_code = f3s[i].code; // Mã giới thiệu f3
        const f3_time = f3s[i].time; // time f3
        let check_f3 = timerJoin(f3_time) == timerJoin() ? true : false;
        if (check_f3) f_all_today += 1;
        const [f4s] = await connection.query(
          "SELECT `phone`, `code`,`invite`, `time` FROM users WHERE `invite` = ? ",
          [f3_code]
        );
        // tổng f3 mời đc hôm nay
        for (let i = 0; i < f4s.length; i++) {
          const f4_code = f4s[i].code; // Mã giới thiệu f4
          const f4_time = f4s[i].time; // time f4
          let check_f4 = timerJoin(f4_time) == timerJoin() ? true : false;
          if (check_f4) f_all_today += 1;
          // tổng f3 mời đc hôm nay
        }
      }
    }
  }

  // Tổng số f2
  let f2 = 0;
  for (let i = 0; i < f1s.length; i++) {
    const f1_code = f1s[i].code; // Mã giới thiệu f1
    const [f2s] = await connection.query(
      "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
      [f1_code]
    );
    f2 += f2s.length;
  }

  // Tổng số f3
  let f3 = 0;
  for (let i = 0; i < f1s.length; i++) {
    const f1_code = f1s[i].code; // Mã giới thiệu f1
    const [f2s] = await connection.query(
      "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
      [f1_code]
    );
    for (let i = 0; i < f2s.length; i++) {
      const f2_code = f2s[i].code;
      const [f3s] = await connection.query(
        "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
        [f2_code]
      );
      if (f3s.length > 0) f3 += f3s.length;
    }
  }

  // Tổng số f4
  let f4 = 0;
  for (let i = 0; i < f1s.length; i++) {
    const f1_code = f1s[i].code; // Mã giới thiệu f1
    const [f2s] = await connection.query(
      "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
      [f1_code]
    );
    for (let i = 0; i < f2s.length; i++) {
      const f2_code = f2s[i].code;
      const [f3s] = await connection.query(
        "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
        [f2_code]
      );
      for (let i = 0; i < f3s.length; i++) {
        const f3_code = f3s[i].code;
        const [f4s] = await connection.query(
          "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
          [f3_code]
        );
        if (f4s.length > 0) f4 += f4s.length;
      }
    }
  }
  // console.log("TOTAL_F_TODAY:" + f_all_today);
  // console.log("F1: " + f1s.length);
  // console.log("F2: " + f2);
  // console.log("F3: " + f3);
  // console.log("F4: " + f4);

  const [recharge] = await connection.query(
    "SELECT SUM(`money`) as total FROM recharge WHERE phone = ? AND status = 1 ",
    [phone]
  );
  const [withdraw] = await connection.query(
    "SELECT SUM(`money`) as total FROM withdraw WHERE phone = ? AND status = 1 ",
    [phone]
  );
  const [bank_user] = await connection.query(
    "SELECT * FROM user_bank WHERE phone = ? ",
    [phone]
  );
  const [telegram_ctv] = await connection.query(
    "SELECT `telegram` FROM point_list WHERE phone = ? ",
    [userInfo.ctv]
  );
  const [ng_moi] = await connection.query(
    "SELECT `phone` FROM users WHERE code = ? ",
    [userInfo.invite]
  );
  return res.status(200).json({
    message: "Success",
    status: true,
    datas: user,
    total_r: recharge,
    total_w: withdraw,
    f1: f1s.length,
    f2: f2,
    f3: f3,
    f4: f4,
    bank_user: bank_user,
    telegram: telegram_ctv[0],
    ng_moi: ng_moi[0],
    daily: userInfo.ctv,
  });
};

const recharge = async (req, res) => {
  let auth = req.cookies.auth;
  if (!auth) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }

  const [recharge] = await connection.query(
    "SELECT * FROM recharge WHERE status = 0 "
  );
  const [recharge2] = await connection.query(
    "SELECT * FROM recharge WHERE status != 0 "
  );
  const [withdraw] = await connection.query(
    "SELECT * FROM withdraw WHERE status = 0 "
  );
  const [withdraw2] = await connection.query(
    "SELECT * FROM withdraw WHERE status != 0 "
  );
  return res.status(200).json({
    message: "Success",
    status: true,
    datas: recharge,
    datas2: recharge2,
    datas3: withdraw,
    datas4: withdraw2,
  });
};

const settingGet = async (req, res) => {
  let auth = req.cookies.auth;
  if (!auth) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }

  const [bank_recharge] = await connection.query(
    "SELECT * FROM bank_recharge "
  );
  const [settings] = await connection.query("SELECT * FROM admin ");
  return res.status(200).json({
    message: "Success",
    status: true,
    settings: settings,
    datas: bank_recharge,
  });
};

const rechargeDuyet = async (req, res) => {
  let auth = req.cookies.auth;
  let id = req.body.id;
  let type = req.body.type;
  if (!auth || !id || !type) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  if (type == "confirm") {
    await connection.query(`UPDATE recharge SET status = 1 WHERE id = ?`, [id]);
    const [info] = await connection.query(
      `SELECT * FROM recharge WHERE id = ?`,
      [id]
    );
    const [userinfo] = await connection.query(
      `SELECT * FROM users WHERE phone = ?`,
      [info[0].phone]
    );
    const [rechcount] = await connection.query(
      `SELECT COUNT(*) as rech_count FROM recharge WHERE phone = ? AND  status = 1  `,
      [info[0].phone]
    );
    await connection.query(
      "UPDATE users SET money = money + ?, total_money = total_money + ? WHERE phone = ? ",
      [info[0].money, info[0].money, info[0].phone]
    );
    if (rechcount[0].rech_count == "1") {
      await connection.query(
        "UPDATE users SET money = money + ?, total_money = total_money + ? WHERE code = ? ",
        [100, 100, userinfo[0].invite]
      );
    }
    return res.status(200).json({
      message: "Successful application confirmation",
      status: true,
      datas: recharge,
    });
  }
  if (type == "delete") {
    await connection.query(`UPDATE recharge SET status = 2 WHERE id = ?`, [id]);

    return res.status(200).json({
      message: "Cancellation successful",
      status: true,
      datas: recharge,
    });
  }
};

const handlWithdraw = async (req, res) => {
  let auth = req.cookies.auth;
  let id = req.body.id;
  let type = req.body.type;
  if (!auth || !id || !type) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  if (type == "confirm") {
    await connection.query(`UPDATE withdraw SET status = 1 WHERE id = ?`, [id]);
    const [info] = await connection.query(
      `SELECT * FROM withdraw WHERE id = ?`,
      [id]
    );
    return res.status(200).json({
      message: "Successful application confirmation",
      status: true,
      datas: recharge,
    });
  }
  if (type == "delete") {
    await connection.query(`UPDATE withdraw SET status = 2 WHERE id = ?`, [id]);
    const [info] = await connection.query(
      `SELECT * FROM withdraw WHERE id = ?`,
      [id]
    );
    await connection.query(
      "UPDATE users SET money = money + ? WHERE phone = ? ",
      [info[0].money, info[0].phone]
    );
    return res.status(200).json({
      message: "Cancel successfully",
      status: true,
      datas: recharge,
    });
  }
};

const settingBank = async (req, res) => {
  let auth = req.cookies.auth;
  let name_bank = req.body.name_bank;
  let name = req.body.name;
  let info = req.body.info;
  let upi = req.body.upi;
  let typer = req.body.typer;
  if (!auth || !typer) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  if (typer == "bank") {
    await connection.query(
      `UPDATE bank_recharge SET name_bank = ?, name_user = ?, stk = ?, upi = ? WHERE type = 'bank'`,
      [name_bank, name, info, upi]
    );
    return res.status(200).json({
      message: "Successful change",
      status: true,
      datas: recharge,
    });
  }
  if (typer == "momo") {
    await connection.query(
      `UPDATE bank_recharge SET name_bank = ?, name_user = ?, stk = ?, upi = ? WHERE type = 'momo'`,
      [name_bank, name, info, upi]
    );
    return res.status(200).json({
      message: "Successful change",
      status: true,
      datas: recharge,
    });
  }
};

const settingCskh = async (req, res) => {
  let auth = req.cookies.auth;
  let telegram = req.body.telegram;
  let cskh = req.body.cskh;
  let myapp_web = req.body.myapp_web;
  if (!auth || !cskh || !telegram) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  await connection.query(`UPDATE admin SET telegram = ?, cskh = ?, app = ?`, [
    telegram,
    cskh,
    myapp_web,
  ]);
  return res.status(200).json({
    message: "Successful change",
    status: true,
  });
};

const banned = async (req, res) => {
  let auth = req.cookies.auth;
  let id = req.body.id;
  let type = req.body.type;
  if (!auth || !id) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  if (type == "open") {
    await connection.query(`UPDATE users SET status = 1 WHERE id = ?`, [id]);
  }
  if (type == "close") {
    await connection.query(`UPDATE users SET status = 2 WHERE id = ?`, [id]);
  }
  return res.status(200).json({
    message: "Successful change",
    status: true,
  });
};

const createBonus = async (req, res) => {
  const randomString = (length) => {
    var result = "";
    var characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  };
  function timerJoin(params = "") {
    let date = "";
    if (params) {
      date = new Date(Number(params));
    } else {
      date = Date.now();
      date = new Date(Number(date));
    }
    let years = formateT(date.getFullYear());
    let months = formateT(date.getMonth() + 1);
    let days = formateT(date.getDate());
    let weeks = formateT(date.getDay());

    let hours = formateT(date.getHours());
    let minutes = formateT(date.getMinutes());
    let seconds = formateT(date.getSeconds());
    // return years + '-' + months + '-' + days + ' ' + hours + '-' + minutes + '-' + seconds;
    return years + "" + months + "" + days;
  }
  const d = new Date();
  const time = d.getTime();

  let auth = req.cookies.auth;
  let money = req.body.money;
  let type = req.body.type;
  let giftType = req.body.giftType;
  let giftCode = req.body.giftCode;


  if (!money || !auth) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  const [user] = await connection.query(
    "SELECT * FROM users WHERE token = ? ",
    [auth]
  );

  if (user.length == 0) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  let userInfo = user[0];

  if (type == "all") {
    let select = req.body.select;
    if (select == "1") {
      await connection.query(
        `UPDATE point_list SET money = money + ? WHERE level = 2`,
        [money]
      );
    } else {
      await connection.query(
        `UPDATE point_list SET money = money - ? WHERE level = 2`,
        [money]
      );
    }
    return res.status(200).json({
      message: "Successful change",
      status: true,
    });
  }

  if (type == "two") {
    let select = req.body.select;
    if (select == "1") {
      await connection.query(
        `UPDATE point_list SET money_us = money_us + ? WHERE level = 2`,
        [money]
      );
    } else {
      await connection.query(
        `UPDATE point_list SET money_us = money_us - ? WHERE level = 2`,
        [money]
      );
    }
    return res.status(200).json({
      message: "Successful change",
      status: true,
    });
  }

  if (type == "one") {
    let select = req.body.select;
    let phone = req.body.phone;
    const [user] = await connection.query(
      "SELECT * FROM point_list WHERE phone = ? ",
      [phone]
    );
    if (user.length == 0) {
      return res.status(200).json({
        message: "Failed",
        status: false,
        timeStamp: timeNow,
      });
    }
    if (select == "1") {
      await connection.query(
        `UPDATE point_list SET money = money + ? WHERE level = 2 and phone = ?`,
        [money, phone]
      );
    } else {
      await connection.query(
        `UPDATE point_list SET money = money - ? WHERE level = 2 and phone = ?`,
        [money, phone]
      );
    }
    return res.status(200).json({
      message: "Successful change",
      status: true,
    });
  }

  if (type == "three") {
    let select = req.body.select;
    let phone = req.body.phone;
    const [user] = await connection.query(
      "SELECT * FROM point_list WHERE phone = ? ",
      [phone]
    );
    if (user.length == 0) {
      return res.status(200).json({
        message: "帐号不存在",
        status: false,
        timeStamp: timeNow,
      });
    }
    if (select == "1") {
      await connection.query(
        `UPDATE point_list SET money_us = money_us + ? WHERE level = 2 and phone = ?`,
        [money, phone]
      );
    } else {
      await connection.query(
        `UPDATE point_list SET money_us = money_us - ? WHERE level = 2 and phone = ?`,
        [money, phone]
      );
    }
    return res.status(200).json({
      message: "Successful change",
      status: true,
    });
  }

  if (!type) {
    let id_redenvelops = String(timerJoin()) + randomString(16);
    let sql = `INSERT INTO redenvelopes SET id_redenvelope = ?, phone = ?, money = ?, used = ?, amount = ?, status = ?, time = ?, gift_type = ?`;
    console.log('GGGGGGGGGGGGGGGGGGGGGGGGGGGGG');
    console.log(sql);
    await connection.query(sql, [
      giftCode,
      userInfo.phone,
      money,
      1,
      1,
      0,
      time,
      giftType,
    ]);    
    return res.status(200).json({
      message: "Successful change",
      status: true,
      id: id_redenvelops,
    });
  }
};

const listRedenvelops = async (req, res) => {
  let auth = req.cookies.auth;

  let [redenvelopes] = await connection.query(
    "SELECT * FROM redenvelopes WHERE status = 0 "
  );
  return res.status(200).json({
    message: "Successful change",
    status: true,
    redenvelopes: redenvelopes,
  });
};

const settingbuff = async (req, res) => {
  let auth = req.cookies.auth;
  let id_user = req.body.id_user;
  let buff_acc = req.body.buff_acc;
  let money_value = req.body.money_value;
  if (!id_user || !buff_acc || !money_value) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  const [user_id] = await connection.query(
    `SELECT * FROM users WHERE id_user = ?`,
    [id_user]
  );

  if (user_id.length > 0) {
    if (buff_acc == "1") {
      await connection.query(
        `UPDATE users SET money = money + ? WHERE id_user = ?`,
        [money_value, id_user]
      );
    }
    if (buff_acc == "2") {
      await connection.query(
        `UPDATE users SET money = money - ? WHERE id_user = ?`,
        [money_value, id_user]
      );
    }
    return res.status(200).json({
      message: "Successful change",
      status: true,
    });
  } else {
    return res.status(200).json({
      message: "Successful change",
      status: false,
    });
  }
};
const randomNumber = (min, max) => {
  return String(Math.floor(Math.random() * (max - min + 1)) + min);
};

const randomString = (length) => {
  var result = "";
  var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
};

const ipAddress = (req) => {
  let ip = "";
  if (req.headers["x-forwarded-for"]) {
    ip = req.headers["x-forwarded-for"].split(",")[0];
  } else if (req.connection && req.connection.remoteAddress) {
    ip = req.connection.remoteAddress;
  } else {
    ip = req.ip;
  }
  return ip;
};

const timeCreate = () => {
  const d = new Date();
  const time = d.getTime();
  return time;
};

const register = async (req, res) => {
  let { username, password, invitecode } = req.body;
  let id_user = randomNumber(10000, 99999);
  let name_user = "Member" + randomNumber(10000, 99999);
  let code = randomString(5) + randomNumber(10000, 99999);
  let ip = ipAddress(req);
  let time = timeCreate();

  invitecode = "2cOCs36373";

  if (!username || !password || !invitecode) {
    return res.status(200).json({
      message: "ERROR!!!",
      status: false,
    });
  }

  if (!username) {
    return res.status(200).json({
      message: "phone error",
      status: false,
    });
  }

  try {
    const [check_u] = await connection.query(
      "SELECT * FROM users WHERE phone = ? ",
      [username]
    );
    if (check_u.length == 1) {
      return res.status(200).json({
        message: "注册账户", //Số điện thoại đã được đăng ký
        status: false,
      });
    } else {
      const sql = `INSERT INTO users SET 
            id_user = ?,
            phone = ?,
            name_user = ?,
            password = ?,
            money = ?,
            level = ?,
            code = ?,
            invite = ?,
            veri = ?,
            ip_address = ?,
            status = ?,
            time = ?`;
      await connection.execute(sql, [
        id_user,
        username,
        name_user,
        md5(password),
        0,
        2,
        code,
        invitecode,
        1,
        ip,
        1,
        time,
      ]);
      await connection.execute(
        "INSERT INTO point_list SET phone = ?, level = 2",
        [username]
      );
      return res.status(200).json({
        message: "注册成功", //Register Sucess
        status: true,
      });
    }
  } catch (error) {
    if (error) console.log(error);
  }
};

const profileUser = async (req, res) => {
  let phone = req.body.phone;
  if (!phone) {
    return res.status(200).json({
      message: "Phone Error",
      status: false,
      timeStamp: timeNow,
    });
  }
  let [user] = await connection.query(`SELECT * FROM users WHERE phone = ?`, [
    phone,
  ]);

  if (user.length == 0) {
    return res.status(200).json({
      message: "Phone Error",
      status: false,
      timeStamp: timeNow,
    });
  }
  let [recharge] = await connection.query(
    `SELECT * FROM recharge WHERE phone = ? ORDER BY id DESC LIMIT 10`,
    [phone]
  );
  let [withdraw] = await connection.query(
    `SELECT * FROM withdraw WHERE phone = ? ORDER BY id DESC LIMIT 10`,
    [phone]
  );
  return res.status(200).json({
    message: "Nhận thành công",
    status: true,
    recharge: recharge,
    withdraw: withdraw,
  });
};

const infoCtv = async (req, res) => {
  const phone = req.body.phone;

  const [user] = await connection.query(
    "SELECT * FROM users WHERE phone = ? ",
    [phone]
  );

  if (user.length == 0) {
    return res.status(200).json({
      message: "Phone Error",
      status: false,
    });
  }
  let userInfo = user[0];
  // cấp dưới trực tiếp all
  const [f1s] = await connection.query(
    "SELECT `phone`, `code`,`invite`, `time` FROM users WHERE `invite` = ? ",
    [userInfo.code]
  );

  // cấp dưới trực tiếp hôm nay
  let f1_today = 0;
  for (let i = 0; i < f1s.length; i++) {
    const f1_time = f1s[i].time; // Mã giới thiệu f1
    let check = timerJoin(f1_time) == timerJoin() ? true : false;
    if (check) {
      f1_today += 1;
    }
  }

  // tất cả cấp dưới hôm nay
  let f_all_today = 0;
  for (let i = 0; i < f1s.length; i++) {
    const f1_code = f1s[i].code; // Mã giới thiệu f1
    const f1_time = f1s[i].time; // time f1
    let check_f1 = timerJoin(f1_time) == timerJoin() ? true : false;
    if (check_f1) f_all_today += 1;
    // tổng f1 mời đc hôm nay
    const [f2s] = await connection.query(
      "SELECT `phone`, `code`,`invite`, `time` FROM users WHERE `invite` = ? ",
      [f1_code]
    );
    for (let i = 0; i < f2s.length; i++) {
      const f2_code = f2s[i].code; // Mã giới thiệu f2
      const f2_time = f2s[i].time; // time f2
      let check_f2 = timerJoin(f2_time) == timerJoin() ? true : false;
      if (check_f2) f_all_today += 1;
      // tổng f2 mời đc hôm nay
      const [f3s] = await connection.query(
        "SELECT `phone`, `code`,`invite`, `time` FROM users WHERE `invite` = ? ",
        [f2_code]
      );
      for (let i = 0; i < f3s.length; i++) {
        const f3_code = f3s[i].code; // Mã giới thiệu f3
        const f3_time = f3s[i].time; // time f3
        let check_f3 = timerJoin(f3_time) == timerJoin() ? true : false;
        if (check_f3) f_all_today += 1;
        const [f4s] = await connection.query(
          "SELECT `phone`, `code`,`invite`, `time` FROM users WHERE `invite` = ? ",
          [f3_code]
        );
        // tổng f3 mời đc hôm nay
        for (let i = 0; i < f4s.length; i++) {
          const f4_code = f4s[i].code; // Mã giới thiệu f4
          const f4_time = f4s[i].time; // time f4
          let check_f4 = timerJoin(f4_time) == timerJoin() ? true : false;
          if (check_f4) f_all_today += 1;
          // tổng f3 mời đc hôm nay
        }
      }
    }
  }

  // Tổng số f2
  let f2 = 0;
  for (let i = 0; i < f1s.length; i++) {
    const f1_code = f1s[i].code; // Mã giới thiệu f1
    const [f2s] = await connection.query(
      "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
      [f1_code]
    );
    f2 += f2s.length;
  }

  // Tổng số f3
  let f3 = 0;
  for (let i = 0; i < f1s.length; i++) {
    const f1_code = f1s[i].code; // Mã giới thiệu f1
    const [f2s] = await connection.query(
      "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
      [f1_code]
    );
    for (let i = 0; i < f2s.length; i++) {
      const f2_code = f2s[i].code;
      const [f3s] = await connection.query(
        "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
        [f2_code]
      );
      if (f3s.length > 0) f3 += f3s.length;
    }
  }

  // Tổng số f4
  let f4 = 0;
  for (let i = 0; i < f1s.length; i++) {
    const f1_code = f1s[i].code; // Mã giới thiệu f1
    const [f2s] = await connection.query(
      "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
      [f1_code]
    );
    for (let i = 0; i < f2s.length; i++) {
      const f2_code = f2s[i].code;
      const [f3s] = await connection.query(
        "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
        [f2_code]
      );
      for (let i = 0; i < f3s.length; i++) {
        const f3_code = f3s[i].code;
        const [f4s] = await connection.query(
          "SELECT `phone`, `code`,`invite` FROM users WHERE `invite` = ? ",
          [f3_code]
        );
        if (f4s.length > 0) f4 += f4s.length;
      }
    }
  }

  const [list_mem] = await connection.query(
    "SELECT * FROM users WHERE ctv = ? AND status = 1 AND veri = 1 ",
    [phone]
  );
  const [list_mem_baned] = await connection.query(
    "SELECT * FROM users WHERE ctv = ? AND status = 2 AND veri = 1 ",
    [phone]
  );
  let total_recharge = 0;
  let total_withdraw = 0;
  for (let i = 0; i < list_mem.length; i++) {
    let phone = list_mem[i].phone;
    const [recharge] = await connection.query(
      "SELECT SUM(money) as money FROM recharge WHERE phone = ? AND status = 1 ",
      [phone]
    );
    const [withdraw] = await connection.query(
      "SELECT SUM(money) as money FROM withdraw WHERE phone = ? AND status = 1 ",
      [phone]
    );
    if (recharge[0].money) {
      total_recharge += Number(recharge[0].money);
    }
    if (withdraw[0].money) {
      total_withdraw += Number(withdraw[0].money);
    }
  }

  let total_recharge_today = 0;
  let total_withdraw_today = 0;
  for (let i = 0; i < list_mem.length; i++) {
    let phone = list_mem[i].phone;
    const [recharge_today] = await connection.query(
      "SELECT `money`, `time` FROM recharge WHERE phone = ? AND status = 1 ",
      [phone]
    );
    const [withdraw_today] = await connection.query(
      "SELECT `money`, `time` FROM withdraw WHERE phone = ? AND status = 1 ",
      [phone]
    );
    for (let i = 0; i < recharge_today.length; i++) {
      let today = timerJoin();
      let time = timerJoin(recharge_today[i].time);
      if (time == today) {
        total_recharge_today += recharge_today[i].money;
      }
    }
    for (let i = 0; i < withdraw_today.length; i++) {
      let today = timerJoin();
      let time = timerJoin(withdraw_today[i].time);
      if (time == today) {
        total_withdraw_today += withdraw_today[i].money;
      }
    }
  }

  let win = 0;
  let loss = 0;
  for (let i = 0; i < list_mem.length; i++) {
    let phone = list_mem[i].phone;
    const [wins] = await connection.query(
      "SELECT `money`, `time` FROM minutes_1 WHERE phone = ? AND status = 1 ",
      [phone]
    );
    const [losses] = await connection.query(
      "SELECT `money`, `time` FROM minutes_1 WHERE phone = ? AND status = 2 ",
      [phone]
    );
    for (let i = 0; i < wins.length; i++) {
      let today = timerJoin();
      let time = timerJoin(wins[i].time);
      if (time == today) {
        win += wins[i].money;
      }
    }
    for (let i = 0; i < losses.length; i++) {
      let today = timerJoin();
      let time = timerJoin(losses[i].time);
      if (time == today) {
        loss += losses[i].money;
      }
    }
  }
  let list_mems = [];
  const [list_mem_today] = await connection.query(
    "SELECT * FROM users WHERE ctv = ? AND status = 1 AND veri = 1 ",
    [phone]
  );
  for (let i = 0; i < list_mem_today.length; i++) {
    let today = timerJoin();
    let time = timerJoin(list_mem_today[i].time);
    if (time == today) {
      list_mems.push(list_mem_today[i]);
    }
  }

  const [point_list] = await connection.query(
    "SELECT * FROM point_list WHERE phone = ? ",
    [phone]
  );
  let moneyCTV = point_list[0].money;

  let list_recharge_news = [];
  let list_withdraw_news = [];
  for (let i = 0; i < list_mem.length; i++) {
    let phone = list_mem[i].phone;
    const [recharge_today] = await connection.query(
      "SELECT `id`, `status`, `type`,`phone`, `money`, `time` FROM recharge WHERE phone = ? AND status = 1 ",
      [phone]
    );
    const [withdraw_today] = await connection.query(
      "SELECT `id`, `status`,`phone`, `money`, `time` FROM withdraw WHERE phone = ? AND status = 1 ",
      [phone]
    );
    for (let i = 0; i < recharge_today.length; i++) {
      let today = timerJoin();
      let time = timerJoin(recharge_today[i].time);
      if (time == today) {
        list_recharge_news.push(recharge_today[i]);
      }
    }
    for (let i = 0; i < withdraw_today.length; i++) {
      let today = timerJoin();
      let time = timerJoin(withdraw_today[i].time);
      if (time == today) {
        list_withdraw_news.push(withdraw_today[i]);
      }
    }
  }

  const [redenvelopes_used] = await connection.query(
    "SELECT * FROM redenvelopes_used WHERE phone = ? ",
    [phone]
  );
  let redenvelopes_used_today = [];
  for (let i = 0; i < redenvelopes_used.length; i++) {
    let today = timerJoin();
    let time = timerJoin(redenvelopes_used[i].time);
    if (time == today) {
      redenvelopes_used_today.push(redenvelopes_used[i]);
    }
  }

  const [financial_details] = await connection.query(
    "SELECT * FROM financial_details WHERE phone = ? ",
    [phone]
  );
  let financial_details_today = [];
  for (let i = 0; i < financial_details.length; i++) {
    let today = timerJoin();
    let time = timerJoin(financial_details[i].time);
    if (time == today) {
      financial_details_today.push(financial_details[i]);
    }
  }

  return res.status(200).json({
    message: "Success",
    status: true,
    datas: user,
    f1: f1s.length,
    f2: f2,
    f3: f3,
    f4: f4,
    list_mems: list_mems,
    total_recharge: total_recharge,
    total_withdraw: total_withdraw,
    total_recharge_today: total_recharge_today,
    total_withdraw_today: total_withdraw_today,
    list_mem_baned: list_mem_baned.length,
    win: win,
    loss: loss,
    list_recharge_news: list_recharge_news,
    list_withdraw_news: list_withdraw_news,
    moneyCTV: moneyCTV,
    redenvelopes_used: redenvelopes_used_today,
    financial_details_today: financial_details_today,
  });
};

const infoCtv2 = async (req, res) => {
  const phone = req.body.phone;
  const timeDate = req.body.timeDate;

  function timerJoin(params = "") {
    let date = "";
    if (params) {
      date = new Date(Number(params));
    } else {
      date = Date.now();
      date = new Date(Number(date));
    }
    let years = formateT(date.getFullYear());
    let months = formateT(date.getMonth() + 1);
    let days = formateT(date.getDate());
    let weeks = formateT(date.getDay());

    let hours = formateT(date.getHours());
    let minutes = formateT(date.getMinutes());
    let seconds = formateT(date.getSeconds());
    // return years + '-' + months + '-' + days + ' ' + hours + '-' + minutes + '-' + seconds;
    return years + "-" + months + "-" + days;
  }

  const [user] = await connection.query(
    "SELECT * FROM users WHERE phone = ? ",
    [phone]
  );

  if (user.length == 0) {
    return res.status(200).json({
      message: "Phone Error",
      status: false,
    });
  }
  let userInfo = user[0];
  const [list_mem] = await connection.query(
    "SELECT * FROM users WHERE ctv = ? AND status = 1 AND veri = 1 ",
    [phone]
  );

  let list_mems = [];
  const [list_mem_today] = await connection.query(
    "SELECT * FROM users WHERE ctv = ? AND status = 1 AND veri = 1 ",
    [phone]
  );
  for (let i = 0; i < list_mem_today.length; i++) {
    let today = timeDate;
    let time = timerJoin(list_mem_today[i].time);
    if (time == today) {
      list_mems.push(list_mem_today[i]);
    }
  }

  let list_recharge_news = [];
  let list_withdraw_news = [];
  for (let i = 0; i < list_mem.length; i++) {
    let phone = list_mem[i].phone;
    const [recharge_today] = await connection.query(
      "SELECT `id`, `status`, `type`,`phone`, `money`, `time` FROM recharge WHERE phone = ? AND status = 1 ",
      [phone]
    );
    const [withdraw_today] = await connection.query(
      "SELECT `id`, `status`,`phone`, `money`, `time` FROM withdraw WHERE phone = ? AND status = 1 ",
      [phone]
    );
    for (let i = 0; i < recharge_today.length; i++) {
      let today = timeDate;
      let time = timerJoin(recharge_today[i].time);
      if (time == today) {
        list_recharge_news.push(recharge_today[i]);
      }
    }
    for (let i = 0; i < withdraw_today.length; i++) {
      let today = timeDate;
      let time = timerJoin(withdraw_today[i].time);
      if (time == today) {
        list_withdraw_news.push(withdraw_today[i]);
      }
    }
  }

  const [redenvelopes_used] = await connection.query(
    "SELECT * FROM redenvelopes_used WHERE phone = ? ",
    [phone]
  );
  let redenvelopes_used_today = [];
  for (let i = 0; i < redenvelopes_used.length; i++) {
    let today = timeDate;
    let time = timerJoin(redenvelopes_used[i].time);
    if (time == today) {
      redenvelopes_used_today.push(redenvelopes_used[i]);
    }
  }

  const [financial_details] = await connection.query(
    "SELECT * FROM financial_details WHERE phone = ? ",
    [phone]
  );
  let financial_details_today = [];
  for (let i = 0; i < financial_details.length; i++) {
    let today = timeDate;
    let time = timerJoin(financial_details[i].time);
    if (time == today) {
      financial_details_today.push(financial_details[i]);
    }
  }

  return res.status(200).json({
    message: "Success",
    status: true,
    datas: user,
    list_mems: list_mems,
    list_recharge_news: list_recharge_news,
    list_withdraw_news: list_withdraw_news,
    redenvelopes_used: redenvelopes_used_today,
    financial_details_today: financial_details_today,
  });
};

const listRechargeMem = async (req, res) => {
  let auth = req.cookies.auth;
  let phone = req.params.phone;
  let { pageno, limit } = req.body;

  if (!pageno || !limit) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

  if (pageno < 0 || limit < 0) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

  if (!phone) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }

  const [user] = await connection.query(
    "SELECT * FROM users WHERE phone = ? ",
    [phone]
  );
  const [auths] = await connection.query(
    "SELECT * FROM users WHERE token = ? ",
    [auth]
  );

  if (user.length == 0 || auths.length == 0) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  let { token, password, otp, level, ...userInfo } = user[0];

  const [recharge] = await connection.query(
    `SELECT * FROM recharge WHERE phone = ? ORDER BY id DESC LIMIT ${pageno}, ${limit} `,
    [phone]
  );
  const [total_users] = await connection.query(
    `SELECT * FROM recharge WHERE phone = ?`,
    [phone]
  );
  return res.status(200).json({
    message: "Success",
    status: true,
    datas: recharge,
    page_total: Math.ceil(total_users.length / limit),
  });
};

const listWithdrawMem = async (req, res) => {
  let auth = req.cookies.auth;
  let phone = req.params.phone;
  let { pageno, limit } = req.body;

  if (!pageno || !limit) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

  if (pageno < 0 || limit < 0) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

  if (!phone) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }

  const [user] = await connection.query(
    "SELECT * FROM users WHERE phone = ? ",
    [phone]
  );
  const [auths] = await connection.query(
    "SELECT * FROM users WHERE token = ? ",
    [auth]
  );

  if (user.length == 0 || auths.length == 0) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  let { token, password, otp, level, ...userInfo } = user[0];

  const [withdraw] = await connection.query(
    `SELECT * FROM withdraw WHERE phone = ? ORDER BY id DESC LIMIT ${pageno}, ${limit} `,
    [phone]
  );
  const [total_users] = await connection.query(
    `SELECT * FROM withdraw WHERE phone = ?`,
    [phone]
  );
  return res.status(200).json({
    message: "Success",
    status: true,
    datas: withdraw,
    page_total: Math.ceil(total_users.length / limit),
  });
};

const listRedenvelope = async (req, res) => {
  let auth = req.cookies.auth;
  let phone = req.params.phone;
  let { pageno, limit } = req.body;

  if (!pageno || !limit) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

  if (pageno < 0 || limit < 0) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

  if (!phone) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }

  const [user] = await connection.query(
    "SELECT * FROM users WHERE phone = ? ",
    [phone]
  );
  const [auths] = await connection.query(
    "SELECT * FROM users WHERE token = ? ",
    [auth]
  );

  if (user.length == 0 || auths.length == 0) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  let { token, password, otp, level, ...userInfo } = user[0];

  const [redenvelopes_used] = await connection.query(
    `SELECT * FROM redenvelopes_used WHERE phone_used = ? ORDER BY id DESC LIMIT ${pageno}, ${limit} `,
    [phone]
  );
  const [total_users] = await connection.query(
    `SELECT * FROM redenvelopes_used WHERE phone_used = ?`,
    [phone]
  );
  return res.status(200).json({
    message: "Success",
    status: true,
    datas: redenvelopes_used,
    page_total: Math.ceil(total_users.length / limit),
  });
};

const listBet = async (req, res) => {
  let auth = req.cookies.auth;
  let phone = req.params.phone;
  let { pageno, limit } = req.body;

  if (!pageno || !limit) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

  if (pageno < 0 || limit < 0) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }

  if (!phone) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }

  const [user] = await connection.query(
    "SELECT * FROM users WHERE phone = ? ",
    [phone]
  );
  const [auths] = await connection.query(
    "SELECT * FROM users WHERE token = ? ",
    [auth]
  );

  if (user.length == 0 || auths.length == 0) {
    return res.status(200).json({
      message: "Failed",
      status: false,
      timeStamp: timeNow,
    });
  }
  let { token, password, otp, level, ...userInfo } = user[0];

  const [listBet] = await connection.query(
    `SELECT * FROM minutes_1 WHERE phone = ? AND status != 0 ORDER BY id DESC LIMIT ${pageno}, ${limit} `,
    [phone]
  );
  const [total_users] = await connection.query(
    `SELECT * FROM minutes_1 WHERE phone = ? AND status != 0`,
    [phone]
  );
  return res.status(200).json({
    message: "Success",
    status: true,
    datas: listBet,
    page_total: Math.ceil(total_users.length / limit),
  });
};

const listOrderOld = async (req, res) => {
  let { gameJoin } = req.body;

  let checkGame = ["1", "3", "5", "10"].includes(String(gameJoin));
  if (!checkGame) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }
  let game = Number(gameJoin);

  let join = "";
  if (game == 1) join = "k5d";
  if (game == 3) join = "k5d3";
  if (game == 5) join = "k5d5";
  if (game == 10) join = "k5d10";

  const [k5d] = await connection.query(
    `SELECT * FROM 5d WHERE status != 0 AND game = '${game}' ORDER BY id DESC LIMIT 10 `
  );
  const [period] = await connection.query(
    `SELECT period FROM 5d WHERE status = 0 AND game = '${game}' ORDER BY id DESC LIMIT 1 `
  );
  const [waiting] = await connection.query(
    `SELECT phone, money, price, amount, bet FROM result_5d WHERE status = 0 AND level = 0 AND game = '${game}' ORDER BY id ASC `
  );
  const [settings] = await connection.query(`SELECT ${join} FROM admin`);
  if (k5d.length == 0) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }
  if (!k5d[0] || !period[0]) {
    return res.status(200).json({
      message: "Error!",
      status: false,
    });
  }
  return res.status(200).json({
    code: 0,
    msg: "Nhận thành công",
    data: {
      gameslist: k5d,
    },
    bet: waiting,
    settings: settings,
    join: join,
    period: period[0].period,
    status: true,
  });
};

const listOrderOldK3 = async (req, res) => {
  let { gameJoin } = req.body;

  let checkGame = ["1", "3", "5", "10"].includes(String(gameJoin));
  if (!checkGame) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }
  let game = Number(gameJoin);

  let join = "";
  if (game == 1) join = "k3d";
  if (game == 3) join = "k3d3";
  if (game == 5) join = "k3d5";
  if (game == 10) join = "k3d10";

  const [k5d] = await connection.query(
    `SELECT * FROM k3 WHERE status != 0 AND game = '${game}' ORDER BY id DESC LIMIT 10 `
  );
  const [period] = await connection.query(
    `SELECT period FROM k3 WHERE status = 0 AND game = '${game}' ORDER BY id DESC LIMIT 1 `
  );
  const [waiting] = await connection.query(
    `SELECT phone, money, price, typeGame, amount, bet FROM result_k3 WHERE status = 0 AND level = 0 AND game = '${game}' ORDER BY id ASC `
  );
  const [settings] = await connection.query(`SELECT ${join} FROM admin`);
  if (k5d.length == 0) {
    return res.status(200).json({
      code: 0,
      msg: "No more data",
      data: {
        gameslist: [],
      },
      status: false,
    });
  }
  if (!k5d[0] || !period[0]) {
    return res.status(200).json({
      message: "Error!",
      status: false,
    });
  }
  return res.status(200).json({
    code: 0,
    msg: "Get success",
    data: {
      gameslist: k5d,
    },
    bet: waiting,
    settings: settings,
    join: join,
    period: period[0].period,
    status: true,
  });
};

const editResult = async (req, res) => {
  // console.log(req)
  let { game, list } = req.body;
  console.log(game, list);
  if (!list || !game) {
    return res.status(200).json({
      message: "ERROR!!!",
      status: false,
    });
  }

  let join = "";
  if (game == 1) join = "k5d";
  if (game == 3) join = "k5d3";
  if (game == 5) join = "k5d5";
  if (game == 10) join = "k5d10";

  const sql = `UPDATE admin SET ${join} = ?`;
  await connection.execute(sql, [list]);
  return res.status(200).json({
    message: "Editing is successful", //Register Sucess
    status: true,
  });
};

const editResult2 = async (req, res) => {
  let { game, list } = req.body;

  if (!list || !game) {
    return res.status(200).json({
      message: "ERROR!!!",
      status: false,
    });
  }

  let join = "";
  if (game == 1) join = "k3d";
  if (game == 3) join = "k3d3";
  if (game == 5) join = "k3d5";
  if (game == 10) join = "k3d10";

  const sql = `UPDATE admin SET ${join} = ?`;
  await connection.execute(sql, [list]);
  return res.status(200).json({
    message: "Editing is successful", //Register Sucess
    status: true,
  });
};

module.exports = {
  ledgerHistory,
  paymentHistory,
  fundRequests,
  dashboard,
  wingoHistory,
  d5history,
  k3history,
  adminPage,
  adminPage3,
  adminPage5,
  adminPage10,
  totalJoin,
  middlewareAdminController,
  changeAdmin,
  membersPage,
  listMember,
  infoMember,
  userInfo,
  statistical,
  statistical2,
  rechargePage,
  recharge,
  rechargeDuyet,
  rechargeRecord,
  withdrawRecord,
  withdraw,
  handlWithdraw,
  settings,
  editResult2,
  settingBank,
  settingGet,
  settingCskh,
  settingbuff,
  register,
  ctvPage,
  listCTV,
  profileUser,
  ctvProfilePage,
  infoCtv,
  infoCtv2,
  giftPage,
  createBonus,
  listRedenvelops,
  banned,
  listRechargeMem,
  listWithdrawMem,
  listRedenvelope,
  listBet,
  adminPage5d,
  listOrderOld,
  listOrderOldK3,
  editResult,
  adminPageK3,
  getAllRechargeDetails,
  getAllUserData,
  dashboardData,
  listFundRequests,
  updateFundRequestStatus,
  updateWithdrawRequestStatus,
  updateReferralCodeStatus,
  updateRemark,
  searchFundRequests,
  ledgerView,
  paymentSettings,
  saveWowpaySettings,
  saveUpiTokenSettings,
  SavePaymentSettings,
  updatePaymentSettings,
  referralCodesView,
  referralCodes,
  saveUpiSettings,
};
